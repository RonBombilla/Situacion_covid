const datosUrl = 'http://localhost:3000/api/total/';
const url = 'http://localhost:3000/';

//Llamar objetos desde el HTML------------------------------------------------------------------------------
const tablaGeneral = document.getElementById('fullTable');
const graficoGeneral = document.getElementById('myChart');
const navbarClick = document.getElementById('login');
const btnChile = document.getElementById('sitChile');
const chartChile = document.getElementById('myChart2');
const btnHome = document.getElementById('home');

//Evento para regresar a página principal
btnHome.addEventListener('click', (e) => {
    e.preventDefault();
    //Reiniciar vista de items 
    chartChile.style.display = 'none'
    tablaGeneral.style.display = 'block'
    graficoGeneral.style.display = 'block'
    document.getElementById('sitChile').className = 'nav-link active'

});

//Evento de botón de situación de Chile para mostrar Gráfico
btnChile.addEventListener('click', (e) => {
    e.preventDefault();
    //Obtención de token almacenado durante inicio de sesión
    const jwt = localStorage.getItem("jwt-token");
    //Ocultar items al mostrar gráfico de situación de Chile
    tablaGeneral.style.display = 'none'
    graficoGeneral.style.display = 'none'

    //Llamado de función creadora de gráfico situación Chile
    getData2(jwt);

});

//Evento de boton de inicio de Sesión-------------------------------------------------------------------------------
navbarClick.addEventListener('click', (e) => {
    e.preventDefault();
    const loginModal = document.getElementById('login-modal');
    loginModal.innerHTML = `
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Iniciar sesión</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">    

                <form id="js-form">
                        <div class="form-group">
                            <label for="inputEmail">Email address</label>
                            <input id="inputEmail" type="email" class="form-control" aria-describedby="emailHelp">
                        </div>
                        <div class="form-group">
                            <label for="inputPassword">Password</label>
                            <input id="inputPassword" type="password" class="form-control">
                        </div>
                        <button id="log" type="submit" class="btn btn-primary"  >Entrar</button>
                </form>
            
            </div>
        </div>
    </div>
    `
        //console.log(loginModal)
    $(loginModal).modal();

    //LLamado de objetos del HTML por id
    const formulario = document.getElementById('js-form');
    const email = document.getElementById('inputEmail');
    const password = document.getElementById('inputPassword');

    //Evento de formulario de inicio de sesión
    formulario.addEventListener('submit', async(event) => {
        event.preventDefault();
        await postData(email.value, password.value);
        logoutBtn();
        $(loginModal).modal('hide');


    });

    btnChile.style.display = 'block'
    navbarClick.style.display = 'none';
});

//Enviar información para el inicio de sesión----------------------

const postData = async(email, password) => {
    const urlLog = `${url}api/login`;
    const response = await fetch(urlLog, {
        method: 'Post',
        body: JSON.stringify({ email, password })
    });

    //Obtención del token de acceso
    const { token } = await response.json();
    //Almacenar token de acceso
    localStorage.setItem("jwt-token", token);
    //console.log(token);
    return token;
};


//Obtener todos los datos de la API---------------------------------------------------------------

const getData = (async() => {
    try {
        const response = await fetch(datosUrl);
        const data = await response.json();
        //console.log(data);
        return data;

    } catch (error) {
        return error;
    }

});

//Gráfico situación mundial---------------------------------------------------------------------------

const grafico = async() => {
    const { data } = await getData();
    const filtrados = data.filter(paises => paises.active >= 10000)

    const paises = []
    const confirmados = []
    const muertes = []
    const recuperados = []
    const activos = []

    //Filtrar paises con más de 10.000 casos
    filtrados.forEach(e => {
        paises.push(e.location);
        confirmados.push(e.confirmed);
        muertes.push(e.deaths);
        recuperados.push(e.recovered);
        activos.push(e.recovered);
    })

    chart(paises, confirmados, muertes, recuperados, activos);
}

grafico();


const chart = (paises, confirmados, muertes, recuperados, activos) => {
    var ctx = document.getElementById('myChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: paises,
            datasets: [{
                    label: 'Casos confirmados',
                    data: confirmados,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)'
                    ],
                    borderWidth: 1

                },
                {
                    label: 'Total muertes',
                    data: muertes,
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.2)'
                    ],
                    borderColor: [
                        'rgba(54, 162, 235, 1)'
                    ],
                    borderWidth: 1

                },
                {
                    label: 'Total recuperados',
                    data: recuperados,
                    backgroundColor: [
                        'rgba(255, 206, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 206, 86, 1)',
                    ],
                    borderWidth: 1

                }, {
                    label: 'Casos activos',
                    data: activos,
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.2)'
                    ],
                    borderColor: [
                        'rgba(75, 192, 192, 1)',
                    ],
                    borderWidth: 1

                }
            ]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

//Tabla de situación mundial--------------------------------------------------------------------------

const tabla = async() => {
    const { data } = await getData();
    //console.log(data)
    data.forEach(e => {
        document.getElementById('table').innerHTML +=
            `
        <tr>
        <td>${e.location}</td>
        <td>${e.confirmed}</td>
        <td>${e.deaths}</td>
        <td>${e.recovered}</td>
        <td>${e.active}</td>
        <td><button id="${e.location}" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Ver detalles</button></td>
        </tr>
        
        `
    });
}

tabla();


//Gráfico de modal--------------------------------------------------------------------------

const graficoModal = (pais) => {
    const { active, confirmed, location, deaths, recovered } = pais
    const ctx = document.getElementById('myChar').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Casos Activos', 'Casos Confirmados', 'Muertos', 'Recuperados'],
            datasets: [{
                label: "Activos",
                data: [active, confirmed, deaths, recovered],
                backgroundColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                ],
            }],
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: location
                    }
                }
            }
        }
    })
}

//Modal para mostrar gráfico de cada País--------------------------------------------------------
const crearModal = async(nombrePais) => {

    try {
        const urlPost = `http://localhost:3000/api/countries/${nombrePais}`
        const response = await fetch(urlPost)

        const { data } = await response.json();
        const modal = document.getElementById('exampleModal');
        modal.innerHTML = `
            <!-- Modal -->
            
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">${nombrePais}</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                        </div>
                        <div class="modal-body">
                            <canvas id="myChar" width="400" height="400"></canvas>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
        `
        graficoModal(data);
    } catch (error) {
        console.error(error)
    }
}

table.addEventListener('click', event => {
    crearModal(event.target.id);
});
crearModal();


//Obtener datos para gráfico de situación Chile---------------------------------------------------

const getData2 = (async(jwt) => {
    try {

        //Inicio alert de carga de datos
        Swal.fire({
            title: "Cargando...",
            showLoaderOnConfirm: true,
            preConfirm: true,
            allowOutsideClick: false,
        });
        swal.showLoading();

        //Obteniendo datos de la API
        const urlConfirmed = `http://localhost:3000/api/confirmed`
        const responseConfirmed = await fetch(urlConfirmed, {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${jwt}`
            }
        })
        const confirmedData = await responseConfirmed.json();

        const urlDeaths = `http://localhost:3000/api/deaths`
        const responseDeaths = await fetch(urlDeaths, {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${jwt}`
            }
        })
        const deathsData = await responseDeaths.json();

        const urlRecovered = `http://localhost:3000/api/recovered`
        const responseRecovered = await fetch(urlRecovered, {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${jwt}`
            }
        })
        const recoveredData = await responseRecovered.json();

        const confirmados = confirmedData.data
        const muertes = deathsData.data
        const recuperados = recoveredData.data

        //Fin alert de carga
        Swal.close()

        //Mostrar funcion de grafico situación chile
        graficoChile(confirmados, muertes, recuperados);

        //Deshabilitar vinculo de Situación Chile
        document.getElementById('sitChile').className = 'nav-link disabled'


    } catch (error) {
        console.error(error);
    }
})


//Gráfico Situación Chile---------------------------------------------------------------------------
const graficoChile = (confirmed, deaths, recovered) => {

    //Creación de Arreglo y llenado mediante ciclo for Each
    const fechas = []
    const confirmados = []
    confirmed.forEach(e => {
        fechas.push(e.date)
        confirmados.push(e.total)
    });

    //Creación de Arreglo y llenado mediante ciclo for Each
    const muertes = []
    deaths.forEach(e => {
        muertes.push(e.total)
    });

    //Creación de Arreglo y llenado mediante ciclo for Each
    const recuperados = []
    recovered.forEach(e => {
        recuperados.push(e.total)
    });


    const ctx = document.getElementById('myChart2').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: fechas,
            datasets: [{
                    label: "Confirmados",
                    data: confirmados,
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.2)',
                    ],
                    borderColor: [
                        'rgba(75, 192, 192, 1)',
                    ],
                    borderWidth: 1
                },
                {
                    label: "Recuperados",
                    data: recuperados,
                    backgroundColor: [
                        'rgba(153, 102, 255, 0.2)',
                    ],
                    borderColor: [
                        'rgba(153, 102, 255, 1)',
                    ],
                    borderWidth: 1
                },
                {
                    label: "Muertes",
                    data: muertes,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                    ],
                    borderWidth: 1
                },
            ],
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Casos Chile'
                }
            }
        },
    })
}

//Función para ocultar items
const hideSection = (section) => {
    const hide = section;
    if (hide.style.display == "none") {
        hide.style.display = 'block'
    } else {
        hide.style.display = "none"
    }
}


//Botón de logout-----------------------------------------------------------------------------------

const logoutBtn = () => {
    const logout = document.getElementById('logout');

    //Habilitar vínculos mientras no se cierre sesión 
    logout.style.display = 'block'
    btnChile.style.display = 'block'

    //Evento para cerrar sesión
    logout.addEventListener('click', e => {
        e.preventDefault();
        //Ocultar vínculo de cierre de sesión
        hideSection(logout)

        //Eliminar datos de Token
        localStorage.clear();
        //Recargar Página al cerrar sesión
        window.location.reload();
    });

};